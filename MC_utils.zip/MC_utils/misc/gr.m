function out = gr

out =   (1+sqrt(5))/2;
